import http from "../http-common";
import IReportData from "../types/report"

class ReportDataService {
  getAll() {
    return http.get<Array<IReportData>>("/item/getItems");
  }

  get(id: string) {
    return http.get<IReportData>("/item/findby/${id}");
  }

  create(data: IReportData) {
    return http.post<IReportData>("/item/add", data);
  }

  update(data: IReportData, id: any) {
    return http.put<any>("/item/${id}", data);
  }

  delete(id: any) {
    return http.delete<any>("/item/delete/${id}");
  }


  findById(id: string) {
    return http.get<Array<IReportData>>("item/findby/${id}");
  }

}

export default new ReportDataService();