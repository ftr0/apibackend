import http from "../http-common";
import ITodotData from "../types/todo"

class TodoDataService {
  getAll() {
    return http.get<Array<ITodotData>>("/todo/all");
  }

  create(data: ITodotData) {
    return http.post<ITodotData>("/todo/add", data);
  }

  delete(id: any) {
    return http.delete<any>(`/todo/deletee/${id}`);
  }

  deleteAll() {
    return http.delete<any>(`/todo`);
  }
}

export default new TodoDataService();