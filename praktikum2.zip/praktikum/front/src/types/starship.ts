export interface Starship {
    name: string;
    crew: string;
    passengers: string;
    cost_in_credits?: string;
    url: string;
  }
  