export default interface ITodoData {
    id?: any | null,
    text: string
  }