export default interface IReportData {
  id?: any | null,
  date: string,
  content: string,
  homeoffice: string,
  start: string,
  end: string, 
  total: string
}