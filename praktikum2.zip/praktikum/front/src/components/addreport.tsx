import { Component, ChangeEvent } from "react";
import ReportDataService from "../services/reportservice";
import IReportData from '../types/report';

type Props = {};
type State = IReportData & { submitted: boolean };

export default class AddReport extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.onChangeDate = this.onChangeDate.bind(this);
    this.onChangeContent = this.onChangeContent.bind(this);
    this.onChangeHomeoffice = this.onChangeHomeoffice.bind(this);
    this.onChangeStart = this.onChangeStart.bind(this);
    this.onChangeEnd = this.onChangeEnd.bind(this);


    this.saveReport = this.saveReport.bind(this);

    this.state = {
      id: null,
      date: "",
      content: "",
      homeoffice: "",
      start: "",
      end: "",
      total: "",
      submitted: false,
    };
  }

  onChangeDate(e: ChangeEvent<HTMLInputElement>) {this.setState({ date: e.target.value });}
  onChangeContent(e: ChangeEvent<HTMLInputElement>) {this.setState({ content: e.target.value });}
  onChangeHomeoffice(e: ChangeEvent<HTMLInputElement>) { this.setState({homeoffice: e.target.value});}
  onChangeStart(e: ChangeEvent<HTMLInputElement>) { this.setState({start: e.target.value});}
  onChangeEnd(e: ChangeEvent<HTMLInputElement>) {this.setState({ end: e.target.value});}

  saveReport() {
    const data: IReportData = {
      date: this.state.date,
      content: this.state.content,
      homeoffice: this.state.homeoffice,
      start: this.state.start,
      end: this.state.end,
      total: this.state.total,
    };

    ReportDataService.create(data)
      .then((response: any) => {
        this.setState({
          id: response.data.id,
          date: response.data.date,
          content: response.data.content,
          homeoffice: response.data.homeoffice,
          start: response.data.start,
          end: response.data.end,
          submitted: true
        });
        console.log(response.data);
      })
      .catch((e: Error) => {
        console.log(e);
      });
  }

  render() {
    const { submitted, date, content, homeoffice, start, end, total } = this.state;

    return (
      <div className="submit-form">
        {submitted ? (
          <div>
            <h4>new report added!</h4>
          </div>
        ) : (
          <div>
            <div className="form-group">
              <label htmlFor="date">date</label>
              <input
                type="date"
                className="form-control"
                id="date"
                required
                value={date}
                onChange={this.onChangeDate}
                name="date"
              />
            </div>

            <div className="form-group">
              <label htmlFor="content">content</label>
              <input
                type="text"
                className="form-control"
                id="content"
                required
                value={content}
                onChange={this.onChangeContent}
                name="content"
              />
            </div>


            <div className="form-group">
              <label htmlFor="homeoffice">homeoffice</label>
              <input
                type="text"
                className="form-control"
                id="homeoffice"
                required
                value={homeoffice}
                onChange={this.onChangeHomeoffice}
                name="homeoffice"
              />
            </div>

           
            <div className="form-group">
              <label htmlFor="homeoffice">start</label>
              <input
                type="time"
                className="form-control"
                id="start"
                required
                value={start}
                onChange={this.onChangeStart}
                name="start"
              />
            </div>


            <div className="form-group">
              <label htmlFor="end">end</label>
              <input
                type="time"
                className="form-control"
                id="start"
                required
                value={end}
                onChange={this.onChangeEnd}
                name="end"
              />
            </div>


            <button onClick={this.saveReport} className="btn btn-success">
              ad new daily report
            </button>
          </div>
        )}
      </div>
    );
  }
}
