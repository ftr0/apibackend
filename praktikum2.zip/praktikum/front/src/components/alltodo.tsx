import { Component, ChangeEvent } from "react";
import TodoDataService from "../services/todoservice";
import { Link } from "react-router-dom";
import ITodoData from '../types/todo';
import AdTodo from '../components/addtodo';

type Props = {};
type State = {Todos: Array<ITodoData>, currentTodo: ITodoData | null};

export default class TodoList extends Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.retrieveTodos = this.retrieveTodos.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.state = { Todos: [], currentTodo: null };
  }

  componentDidMount() {
    this.retrieveTodos();
  }

  retrieveTodos() {
    TodoDataService.getAll()
      .then((response: any) => {
        this.setState({
          Todos: response.data
        });
        console.log(response.data);
      })
      .catch((e: Error) => {
        console.log(e);
      });
  }

  refreshList() {
    this.retrieveTodos();
    this.setState({ currentTodo: null });
  }


  render() {
    const { Todos } = this.state;

    return (
      <div>
          <h2>praktikum todo list</h2>
          <AdTodo/>
      
          {Todos &&
              Todos.map((Todo: ITodoData, index: number) => (
                
            <div style={{border: "1px solid lightgrey", float: "left", boxShadow: '11px 12px 19px #F4AAB9',textAlign: "center",width: "350px", height: "200px", padding: "50px", margin: "10px", backgroundColor: "lightyellow", fontSize: "30px"}} key={index}> 
            <Link to = {"/todo/delete/" + Todo.id} className="badge badge-warning"> X</Link>
            <br></br>
             {Todo.text}   
             </div>
               ))}
      </div>
    );
  }
}
