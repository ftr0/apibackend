import { Component, ChangeEvent } from "react";
import TodoDataService from "../services/todoservice";
import ITodoData from '../types/todo';

type Props = {};
type State = ITodoData & { submitted: boolean };


export default class AddTodo extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.onChangeText = this.onChangeText.bind(this);
    this.saveTodo = this.saveTodo.bind(this);

    this.state = {
        id: null,
        text: "",
        submitted: false,
      };
    }

  onChangeText(e: ChangeEvent<HTMLInputElement>) {this.setState({ text: e.target.value });}


  saveTodo() {
    const data: ITodoData = {
      text: this.state.text
    };

    TodoDataService.create(data)
      .then((response: any) => {
        this.setState({
          id: response.data.id,
          text: response.data.text,

          submitted: true
        });
        console.log(response.data);
      })
      .catch((e: Error) => {
        console.log(e);
      });
  }

  render() {
    const { submitted, text } = this.state;

    return (
      <div className="submit-form">
        {submitted ? (
          <div>
            <h4>new Todo added!</h4>
          </div>
        ) : (
          <div>
            <div className="form-group">
              <label htmlFor="text">todo note:</label>
              <input
                type="text"
                className="form-control"
                id="text"
                required
                value={text}
                onChange={this.onChangeText}
                name="text"
              />

    <button onClick={this.saveTodo} className="btn btn-success">
              add new todo
            </button>
            </div>

            
          </div>
        )}
      </div>
    );
  }
}
