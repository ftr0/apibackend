import React, { useState, useEffect } from 'react';
    
let myArray: string[] = [];
export default function GetData() {  
    const [info, setData] = useState([]);
    
    useEffect(() => {
        getMyData();
    }, []);
    
    const getMyData = async () => {
        const response = await fetch('https://pokeapi.co/api/v2/type')
        const data =await response.json();
        //console.log(data.results)
        for (var i = 0; i < data.results.length; i++) {     
            myArray.push(data.results[i].name)   
            setData(data.results[i].name)
        }
        console.log(info)
    }
   
    return (
        <div>
            <h1>get Data</h1>
           {myArray.map((value,index) => {
               return <li key={index}>{value}</li>;
           })}
        </div>
    )
}