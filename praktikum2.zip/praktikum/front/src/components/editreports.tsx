import { Component, ChangeEvent } from "react";
import { RouteComponentProps } from 'react-router-dom';
import axios from "axios";
import ReportDataService from "../services/reportservice";
import IReportData from "../types/report";

interface RouterProps { // type for `match.params`
  id: string; // must be type `string` since value comes from the URL
}



type Props = RouteComponentProps<RouterProps>;

type State = {
  currentReport: IReportData;
  message: string;
}

export default class Report extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.onChangeDate = this.onChangeDate.bind(this);
    this.getReport = this.getReport.bind(this);
    this.updateReport = this.updateReport.bind(this);
    this.deleteReport = this.deleteReport.bind(this);

    this.state = {
      currentReport: {
        id: null,
        date: "",
        content: "",
        homeoffice: "",
        start: "",
        end: "",
        total: ""
      },
      message: "",
    };
  }

  componentDidMount() {
    this.getReport(this.props.match.params.id);
  }

  onChangeDate(e: ChangeEvent<HTMLInputElement>) {
    const date = e.target.value;

    this.setState(function (prevState) {
      return {
        currentReport: {
          ...prevState.currentReport,
          date: date,
        },
      };
    });
  }

  getReport(id: string) {
    ReportDataService.get(id)
      .then((response: any) => {
        this.setState({
          currentReport: response.data,
        });
        console.log(response.data);
      })
      .catch((e: Error) => {
        console.log(e);
      });
  }

  

  updateReport() {
    ReportDataService.update(
      this.state.currentReport,
      this.state.currentReport.id
    )
      .then((response: any) => {
        console.log(response.data);
        this.setState({
          message: "The Report was updated successfully!",
        });
      })
      .catch((e: Error) => {
        console.log(e);
      });
  }

  deleteReport() {
    ReportDataService.delete(this.props.match.params.id)
      .then((response: any) => {
        console.log(response.data);
        //axios.delete("http://localhost:8080/item/delete/", { data: { id: 192 } });
        this.props.history.push("/item/delete/");

      })
      .catch((e: Error) => {
        console.log(e);
      });
  }

  async getDataAxios(){
    const response =
      await axios.get("http://localhost:8080/item/delete/",
          { params: {id: 192}}
      )
    console.log(response.data)
}
  

  render() {
    const { currentReport } = this.state;

    return (
      <div>
        {currentReport ? (
          <div className="edit-form">
            <h4>Report</h4>
            <form>
              <div className="form-group">
                <label htmlFor="date">date</label>
                <input
                  type="text"
                  className="form-control"
                  id="date"
                  value={currentReport.date}
                  onChange={this.onChangeDate}
                />
              </div>
            

            

            <button
             type="submit"
              className="badge badge-danger mr-2"
              onClick={this.getDataAxios}
            >
              Delete
            </button>

            <button
              type="submit"
              className="badge badge-success"
              onClick={this.updateReport}
            >
              Update
            </button>
            </form>
            <p>{this.state.message}</p>
          </div>
        ) : (
          <div>
            <br />
            <p>Please click on a Report...</p>
          </div>
        )}
      </div>
    );
  }
}
