import { Component, ChangeEvent } from "react";
import ReportDataService from "../services/reportservice";
import { Link } from "react-router-dom";
import IReportData from '../types/report';
import { PieChart } from 'react-minimal-pie-chart';

type Props = {};
type State = {Reports: Array<IReportData>, currentReport: IReportData | null};

export default class ReportsList extends Component<Props, State>{
  constructor(props: Props) {
    super(props);
    this.retrieveReports = this.retrieveReports.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.state = { Reports: [], currentReport: null };
  }

  componentDidMount() {
    this.retrieveReports();
  }

  retrieveReports() {
    ReportDataService.getAll()
      .then((response: any) => {
        this.setState({
          Reports: response.data
        });
        console.log(response.data);
      })
      .catch((e: Error) => {
        console.log(e);
      });
  }

  refreshList() {
    this.retrieveReports();
    this.setState({ currentReport: null });
  }

  render() {
    const { Reports } = this.state;

    return (
      <div>
          <h2>praktikum report list</h2>
           

            <div style={{border: "1px solid lightgrey"}} >
            <table className="table table-striped" >
              <thead>
                <tr>
                  <th style={{width: "5%", padding: "20px"}} scope="col">id</th>
                  <th style={{width: "10%",padding: "20px"}} scope="col">date</th>
                  <th style={{width: "50%",padding: "20px"}} scope="col">content</th>
                  <th style={{width: "10%",padding: "20px"}} scope="col">homeoffice</th>
                  <th style={{width: "5%",padding: "20px"}} scope="col">start</th>
                  <th style={{width: "5%",padding: "20px"}} scope="col">end</th>
                  <th style={{width: "5%",padding: "20px"}} scope="col">total</th>
                  <th style={{width: "20%",padding: "20px"}} scope="col"></th>
                </tr>
              </thead>
              <tbody>
              {Reports &&
              Reports.map((Report: IReportData, index: number) => (
                <tr key={index}>
                  <td style={{width: "5%", padding: "20px"}}>{Report.id}</td>
                  <td style={{width: "5%", padding: "20px"}}>{Report.date}</td>
                  <td style={{width: "5%", padding: "20px"}}>{Report.content}</td>
                  <td style={{width: "5%", padding: "20px"}}>{Report.homeoffice}</td>
                  <td style={{width: "5%", padding: "20px"}}>{Report.start}</td>
                  <td style={{width: "5%", padding: "20px"}}>{Report.end}</td>
                  <td style={{width: "5%", padding: "20px"}}>{Report.total}h</td>
                  <td>
                    <Link to = {"/reports/" + Report.id} className="badge badge-warning"> edit</Link>
                  </td>
                </tr>
         
              ))}
                   </tbody>
            </table>
            
            <div style={{width: "30%", textAlign: "center",margin: "auto"}}>
            <h2>homeoffice:</h2>
              <PieChart 
              data={[
                { title: 'ja', value: 10, color: 'lightgreen' },
                { title: 'nein', value: 15, color: 'lightblue' },
              ]}
            />
          </div>
             </div>
      </div>
    );
  }
}
