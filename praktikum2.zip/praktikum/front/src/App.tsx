

import { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import AddReport from "./components/addreport";
import Report from "./components/editreports";
import ReportsList from "./components/allreports";
import TodoList from "./components/alltodo";

import Home from "./components/homeoffice";







class App extends Component {
  render() {
    return (
      <div>

        <Home/>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          <Link to={"/Reports"} className="navbar-brand">
            praktikum master 2022
          </Link>
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/reports"} className="nav-link">
                all reports
              </Link>
            </li>
            <li className="nav-item">
              <Link to={"/add"} className="nav-link">
                add report
              </Link>
            </li>


            <li className="nav-item">
              <Link to={"/alltodo"} className="nav-link">
                all todos
              </Link>
            </li>


            <li className="nav-item">
            <div className="nav-link">
            © by praktikant
                </div>
            </li>
          </div>
        </nav>

        <div className="container mt-3">
          <Switch>
            <Route exact path={["/", "/reports"]} component={ReportsList} />
            <Route exact path="/add" component={AddReport} />
      
            <Route exact path="/alltodo" component={TodoList} />

            <Route path="/reports/:id" component={Report} />
          </Switch>
        </div>
      </div>
    );
  }
}

export default App;
