package com.example.praktikum.service;

import com.example.praktikum.model.InfoHomeoffice;
import com.example.praktikum.model.Item;
import com.example.praktikum.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

@Service
public class ItemServiceImplementation implements ItemService{

    @Autowired
    private ItemRepository itemRepository;

    @Override
    public Item saveItem(Item item)
    {
        return itemRepository.save(item);
    }

    @Override
    public List<Item> getAllItems()
    {
        return itemRepository.findAll();
    }

    @Override
    public void delete(int id)
    {
        this.itemRepository.deleteById(id);
    }

    @Override
    public Optional < Item > findById(int id) {
        return itemRepository.findById(id);
    }


    public Item getStudent(int id ) {
        Optional<Item> itemResponse =  itemRepository.findById(id);
        Item item = itemResponse.get();
        return item;
    }


    public List<InfoHomeoffice> calculator()
    {
        List<Item> itemlist = new LinkedList<Item>();
        itemlist = itemRepository.findAll();
        int yes = 0;
        int no = 0;
        for (Item item : itemlist)
        {
            if(item.getHomeoffice().equals("yes")) yes++;
            if(item.getHomeoffice().equals("no")) no++;
        }
        InfoHomeoffice infoHomeoffice = new InfoHomeoffice(1,yes,no);

        List<InfoHomeoffice> itemlist2 = new LinkedList<InfoHomeoffice>();
        itemlist2.add(infoHomeoffice);
        return itemlist2;
    }

}
