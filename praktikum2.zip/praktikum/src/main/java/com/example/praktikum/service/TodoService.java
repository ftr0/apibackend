package com.example.praktikum.service;

import com.example.praktikum.model.Todo;

import java.util.List;

public interface TodoService
{
    public Todo saveTodo(Todo todo);

    List<Todo> getAllTodo();

    public void delete(int id);

}
