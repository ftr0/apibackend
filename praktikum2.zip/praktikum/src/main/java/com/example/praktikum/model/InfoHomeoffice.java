package com.example.praktikum.model;

public class InfoHomeoffice
{
    public int getWertJa() {
        return wertJa;
    }

    public void setWertJa(int wertJa) {
        this.wertJa = wertJa;
    }

    public int getWertNein() {
        return wertNein;
    }

    public void setWertNein(int wertNein) {
        this.wertNein = wertNein;
    }

    public InfoHomeoffice(int id, int wertJa, int wertNein) {
        this.id = id;
        this.wertJa = wertJa;
        this.wertNein = wertNein;
    }
    int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    int wertJa;
    int wertNein;


}
