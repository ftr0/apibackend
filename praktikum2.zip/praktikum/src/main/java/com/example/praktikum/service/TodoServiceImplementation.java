package com.example.praktikum.service;

import com.example.praktikum.model.Todo;
import com.example.praktikum.repository.TodoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TodoServiceImplementation implements TodoService
{
    @Autowired
    private TodoRepository todoRepository;

    @Override
    public Todo saveTodo(Todo todo)
    {
        return todoRepository.save(todo);
    }

    @Override
    public List<Todo> getAllTodo()
    {
        return todoRepository.findAll();
    }

    @Override
    public void delete(int id)
    {
        this.todoRepository.deleteById(id);
    }
}
