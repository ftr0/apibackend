package com.example.praktikum.controller;

import com.example.praktikum.model.Todo;
import com.example.praktikum.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/todo")
@CrossOrigin
public class TodoController {
    @Autowired
    private TodoService todoService;

    @PostMapping("/add")
    public String add(@RequestBody Todo todo)
    {
        todoService.saveTodo(todo);
        return "New todo";
    }

    @GetMapping("/all")
    public List<Todo> getAllTodo()
    {
        return todoService.getAllTodo();
    }


    @GetMapping("/delete/{id}")
    public void deleteTodo(@PathVariable (value = "id") int id)
    {
        todoService.delete(id);
    }


}