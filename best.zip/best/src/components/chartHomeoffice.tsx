import {useState, useEffect} from 'react'
import { PieChart } from 'react-minimal-pie-chart';

type Homeoffice = {
  id: number;
  wertYes: String;
  wertNo: String;
}


function ChartHomeoffice() {
  const [homeoffice, setHomeoffice] = useState<Homeoffice[]>([])
  const [error, setError] = useState({})


  useEffect(() => {
    fetch('http://localhost:8080/item/charthomeoffice')
    .then(response => response.json())
    .then(res => setHomeoffice(res.slice(0,10)))
    .catch(err => setError(err))
  }, [])


  const dataMock = [
    { title: 'One', value: 10, color: '#E38627' },
    { title: 'Two', value: 15, color: '#C13C37' },
    { title: 'Three', value: 20, color: '#6A2135' },
  ];

  return (
    <div className="App">


{homeoffice.map(homeoffice => ( 
 <div>
          <h1>{homeoffice.wertYes}2</h1>
          <h1>{homeoffice.wertNo}1</h1>
            {



            }
           <PieChart
        data={dataMock} />


      </div>
    ))} 
         

    </div>
  );
}

export default ChartHomeoffice;