import {useState, useEffect} from 'react'

type Report = {
  id: number;
  content: string;
  date: string;
  homeoffice: string;
  start: string;
  end: string;
}

function TableReports() {
  const [reports, setReports] = useState<Report[]>([])
  const [error, setError] = useState({})

  useEffect(() => {
    fetch('http://localhost:8080/item/getItems')
    .then(response => response.json())
    .then(res => setReports(res.slice(0,10)))
    .catch(err => setError(err))

  }, [])

  return (
    <div className="App">
        <table>
            {reports.map(item => ( 
            <tr>
                <td>{item.content}</td>
                <td>{item.content}</td>
                <td>{item.date}</td>
                <td>{item.homeoffice}</td>
                <td>{item.start}</td>
                <td>{item.end}</td>
            </tr>
            ))}  
        </table>
    </div>
  );
}

export default TableReports;