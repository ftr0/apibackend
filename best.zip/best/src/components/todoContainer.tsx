import {useState, useEffect} from 'react'

type Todo = {
  id: number;
  text: String;
}

function ChartHomeoffice() {
  const [Todos, setTodos] = useState<Todo[]>([])
  const [error, setError] = useState({})


  useEffect(() => {
    fetch('http://localhost:8080/todo/all')
    .then(response => response.json())
    .then(res => setTodos(res.slice(0,10)))
    .catch(err => setError(err))
  }, [])

  return (
    <div className="App">


{Todos.map(todo => ( 
 <div>
          <h2>{todo.text}</h2>
      </div>
    ))} 
         

    </div>
  );
}

export default ChartHomeoffice;