import {useState, useEffect} from 'react'
import TodoContainer from '../components/todoContainer'

function TodoPage() {
  

  return (
    <div className="App">
      <h1>todo</h1>
      <TodoContainer/>
    </div>
  );
}

export default TodoPage;