
import ChartHomeoffice from '../components/chartHomeoffice'
import TableReports from '../components/tableReports'

function ReportPage() {
  

  return (
    <div className="App">
      <h1>reports</h1>
      <TableReports/>
      <ChartHomeoffice/>
    </div>
  );
}

export default ReportPage;