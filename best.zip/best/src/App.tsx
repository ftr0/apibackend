import ReportPage from './pages/ReportPage'
import './App.css';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import TodoPage from './pages/TodoPage';


function App() {

  return (
    <div className="App">
      <a href="/reports" >reports</a> : 
      <a href="/todo" >todo</a> 
        <BrowserRouter>
          <Routes>
            <Route path="/reports" element={<ReportPage />}> </Route>
            <Route path="/todo" element={<TodoPage />}> </Route>
          </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;